package Ejercicio1;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Main7 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		ArrayList<String> extensiones = new ArrayList<String>();
		
		String extension;
		
		boolean seguir = true;
		String seguirletra;
		
		System.out.println("Indica la ruta");
		String ruta = teclado.next();
		
		do {
			System.out.println("Indica una extension");
			extension = teclado.next();
			extensiones.add(extension);
			System.out.println("Quiere indicar otra mas?s/n");
			seguirletra=teclado.next();
			if(seguirletra.equals("s")) {
				seguir=true;
			} else {
				seguir=false;
			}
			
		} while(seguir!=false);
		
		File ejercicio7 = new File(ruta);
		
		for(String lista : extensiones) {
			Filtro f = new Filtro(lista);
			String[] listanombres = ejercicio7.list(f);
			for (int i = 0; i < listanombres.length; i++) {
				System.out.println(listanombres[i]);
			}
		}
		
	}

}

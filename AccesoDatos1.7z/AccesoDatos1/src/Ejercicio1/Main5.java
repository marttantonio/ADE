package Ejercicio1;

import java.io.File;
import java.io.FileFilter;
import java.util.Scanner;

public class Main5 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Indicame el directorio");
		String dir = teclado.next();
		
		System.out.println("Indica la extension del archivo que quieres filtrar");
		String extension = teclado.nextLine();
		
		File ejercicio5 = new File(dir);
		
		Filtro f = new Filtro(extension);
		
		String[] coleccion = ejercicio5.list(f);
		
		for(int i = 0; i<coleccion.length; i++) {
			System.out.println(coleccion[i]);
		}
		
	}

}

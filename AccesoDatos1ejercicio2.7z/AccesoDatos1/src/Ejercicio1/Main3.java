package Ejercicio1;

import java.io.File;
import java.util.Scanner;

public class Main3 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Indicame el directorio");
		String dir1 = teclado.next();
		

		File ejercicio3 = new File(dir1);
		boolean existe;
		
		if(ejercicio3.exists()) {
			existe=true;
		} else
			existe=false;
		
		System.out.println(existe);
	}

}

package Ejercicio1;

import java.io.File;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Indicame el directorio");
		String dir1 = teclado.next();
		

		File ejercicio1 = new File(dir1);
		System.out.println(ejercicio1);
	}

}

package Ejercicio2;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Indica la ruta");
        String ruta = teclado.next();
        
        File ejercicio1 = new File(ruta);
        
        int opcion1;
        String rutaCarpetaCreada = null;
        
        do {
            System.out.println("Indique qué opción desea:");
            System.out.println("1.Obtener Información");
            System.out.println("2.Crear carpeta");
            System.out.println("3.Crear fichero");
            System.out.println("4.Eliminar carpeta/archivo");
            System.out.println("5.Renombrar carpeta/archivo");
            System.out.println("99.Salir");
            opcion1 = teclado.nextInt();
            
            switch (opcion1) {
            case 1:
                getInformacion(ejercicio1);
                break;
            case 2:
                System.out.println("Indique el nombre de la carpeta");
                String nomcarpeta = teclado.next();
                rutaCarpetaCreada = crearCarpeta(nomcarpeta, ejercicio1);
                break;
            case 3:
                if (rutaCarpetaCreada != null) {
                    System.out.println("Indique el nombre del archivo a crear:");
                    String nomarchivo = teclado.next();
                    crearArchivo(nomarchivo, new File(rutaCarpetaCreada));
                } else {
                    System.out.println("Primero debes crear una carpeta en el case 2.");
                }
                break;
            case 4:
            	System.out.println("Introduce toda la ruta");
            	String rutac4 = teclado.next();
            	File rutacase4 = new File(rutac4);
            	if(eliminarArchivo(rutacase4)) {
            		System.out.println("Archivo borrado correctamente");
            	} else {
            		System.out.println("Error al eliminar");
            	}
                break;
            case 5:
            	System.out.println("Introduce toda la ruta del archivo que quieres renombrar");
            	String rutacambiar = teclado.next();
            	File archivoARenombrar = new File(rutacambiar);
            	System.out.println("Introduzca ahora el nuevo nombre (solo el nombre, sin ruta) para el archivo");
            	String nuevoNombre = teclado.next();
            	// Llamada al método renombrarArchivo con la ruta y el nuevo nombre
            	if(renombrarArchivo(archivoARenombrar, nuevoNombre)) {
            		System.out.println("Archivo renombrado correctamente");
            	} else {
            		System.out.println("Error al renombrar");
            	}
                break;
            default:
                System.out.println("Indique un número del 1 al 5");
            }
        } while (opcion1 != 99);
    }

    public static String getInformacion(File archivo) {
        String res = null;
        
        if (archivo.exists()) {
            String nombre = archivo.getName();
            String tipo = archivo.isDirectory() ? "Directorio" : "Archivo";
            String ubicacion = archivo.getAbsolutePath();
            long ultmodificacion = archivo.lastModified();
            boolean oculto = archivo.isHidden();
            String oculto2;
            
            if (oculto) {
                oculto2 = "El archivo está oculto";
            } else {
                oculto2 = "El archivo es visible";
            }
            
            res = nombre + " " + tipo + " " + ubicacion + " " + ultmodificacion + " " + oculto2;
            System.out.println(res);
        } else {
            res = "El archivo no existe";
            System.out.println(res);
        }
        
        return res;
    }
    
    public static String crearCarpeta(String nombre, File archivo) {
        File nuevaCarpeta = new File(archivo, nombre);
        
        if (nuevaCarpeta.mkdir()) {
            System.out.println("Carpeta " + nombre + " creada con éxito en: " + nuevaCarpeta.getAbsolutePath());
            return nuevaCarpeta.getAbsolutePath();
        } else {
            System.out.println("No ha sido posible crear la carpeta.");
            return null;
        }
    }

    public static boolean crearArchivo(String nombre, File carpeta) {
        boolean res = false;
        
        File nuevoArchivo = new File(carpeta, nombre);  
        
        try {
            if (nuevoArchivo.createNewFile()) {
                System.out.println("Archivo " + nombre + " creado con éxito en: " + nuevoArchivo.getAbsolutePath());
                res = true;
            } else {
                System.out.println("No ha sido posible crear el archivo.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return res;
    }
    
    public static boolean eliminarArchivo(File ruta) {
        return ruta.delete();
    }

    public static boolean renombrarArchivo(File archivo, String nuevoNombre) {
        File nuevoArchivo = new File(archivo.getParent(), nuevoNombre);

        return archivo.renameTo(nuevoArchivo);
    }
}

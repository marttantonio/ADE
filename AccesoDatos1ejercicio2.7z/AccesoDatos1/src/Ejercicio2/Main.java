package Ejercicio2;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Indica la ruta");
        String ruta = teclado.next();
        
        File ejercicio1 = new File(ruta);
        
        System.out.println("Indique qué opción desea:");
        System.out.println("1.Obtener Información");
        System.out.println("2.Crear carpeta");
        System.out.println("3.Crear fichero");
        System.out.println("4.Eliminar carpeta/archivo");
        System.out.println("5.Renombrar carpeta/archivo");
        int opcion1 = teclado.nextInt();
        
        File nuevaCarpeta = null;
        
        switch (opcion1) {
        case 1:
            getInformacion(ejercicio1);
            break;
        case 2:
            System.out.println("Indique el nombre de la carpeta");
            String nomcarpeta = teclado.next();
           
            nuevaCarpeta = crearCarpeta(nomcarpeta, ejercicio1);
            break;
        case 3:
        	System.out.println("Indique el nombre de la carpeta donde se creará el archivo:");
            String nombreCarpeta = teclado.next();
            
            if (nuevaCarpeta.getName()==nombreCarpeta) {
                System.out.println("Indique el nombre del archivo a crear:");
                String nomarchivo = teclado.next();
                crearArchivo(nomarchivo, nuevaCarpeta);
            } else {
                System.out.println("Primero debes crear una carpeta en el case 2.");
            }
            
            break;
        case 4:
            break;
        case 5:
            break;
            
        default:
            System.out.println("Indique un número del 1 al 5");
        }
        
        teclado.close();
    }

    public static String getInformacion(File archivo) {
        String res = null;
        
        if (archivo.exists()) {
            String nombre = archivo.getName();
            String tipo = archivo.isDirectory() ? "Directorio" : "Archivo";
            String ubicacion = archivo.getAbsolutePath();
            long ultmodificacion = archivo.lastModified();
            boolean oculto = archivo.isHidden();
            String oculto2;
            
            if (oculto) {
                oculto2 = "El archivo está oculto";
            } else {
                oculto2 = "El archivo es visible";
            }
            
            res = nombre + " " + tipo + " " + ubicacion + " " + ultmodificacion + " " + oculto2;
            
        } else {
            res = "El archivo no existe";
        }
        
        return res;
    }
    
    public static File crearCarpeta(String nombre, File archivo) {
        File nuevaCarpeta = new File(archivo, nombre);
        
        if (nuevaCarpeta.mkdir()) {
            System.out.println("Carpeta " + nombre + " creada con éxito en: " + nuevaCarpeta.getAbsolutePath());
            return nuevaCarpeta;
        } else {
            System.out.println("No ha sido posible crear la carpeta.");
            return null;
        }
    }

    public static boolean crearArchivo(String nombre, File carpeta) {
        boolean res = false;
        
        File nuevoArchivo = new File(carpeta, nombre);  
        
        try {
            if (nuevoArchivo.createNewFile()) {
                System.out.println("Archivo " + nombre + " creado con éxito en: " + nuevoArchivo.getAbsolutePath());
                res = true;
            } else {
                System.out.println("No ha sido posible crear el archivo.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return res;
    }
    
 
}

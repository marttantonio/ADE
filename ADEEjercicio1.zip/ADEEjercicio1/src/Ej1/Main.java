package Ej1;

public class Main {
    public static void main(String[] args) {
        try {
            Modelo modelo = new Modelo("C:\\Users\\DAM2\\Desktop\\ade1\\AE_02_T1_2_Streams_Material\\ejemplo1.txt"); 
            Vision vision = new Vision();
            vision.initialize(); 
            Controlador controlador = new Controlador(modelo, vision);

            String textoOriginal = modelo.leerArchivo();
            vision.getTextAreaOriginal().setText(textoOriginal);  

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

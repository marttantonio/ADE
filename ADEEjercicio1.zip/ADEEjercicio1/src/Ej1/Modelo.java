package Ej1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Modelo {

    private File file;
    private BufferedReader reader;
    private BufferedWriter writer;

    public Modelo(String filePath) throws IOException {
        this.file = new File(filePath);
        if (!file.exists()) {
            throw new FileNotFoundException("El archivo no existe.");
        }
    }

    public String leerArchivo() throws IOException {
        StringBuilder contenido = new StringBuilder();
        reader = new BufferedReader(new FileReader(file)); 
        String linea;

        while ((linea = reader.readLine()) != null) {
            contenido.append(linea).append("\n");
        }
        reader.close();
        return contenido.toString();
    }

    public int buscarPalabra(String palabra) throws IOException {
        String contenido = leerArchivo();
        String[] palabras = contenido.split("\\s+");
        int contador = 0;
        for (String p : palabras) {
            if (p.equalsIgnoreCase(palabra)) {
                contador++;
            }
        }
        return contador;
    }

    public void reemplazarPalabra(String palabraOriginal, String palabraNueva, String nuevoArchivoPath) throws IOException {
        String contenido = leerArchivo();
        String nuevoContenido = contenido.replaceAll(palabraOriginal, palabraNueva);

        writer = new BufferedWriter(new FileWriter(nuevoArchivoPath));
        writer.write(nuevoContenido);
        writer.close();
        
    }
}

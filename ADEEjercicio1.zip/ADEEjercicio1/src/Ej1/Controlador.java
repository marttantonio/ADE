package Ej1;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class Controlador {
    private Modelo modelo;
    private Vision vision;

    public Controlador(Modelo modelo, Vision vision) {
        this.modelo = modelo;
        this.vision = vision;

        vision.getBtnBuscar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String palabra = vision.getTextFieldBuscar().getText(); 
                try {
                    int ocurrencias = modelo.buscarPalabra(palabra);
                    JOptionPane.showMessageDialog(vision.getTextAreaOriginal(), "La palabra '" + palabra + "' aparece " + ocurrencias + " veces.");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(vision.getTextAreaOriginal(), "Error al buscar la palabra.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        vision.getBtnReemplazar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String palabraOriginal = vision.getTextFieldBuscar().getText();  
                String palabraNueva = vision.getTextFieldReemplazar().getText();  
                try {
                    String nuevoArchivo = "nuevoArchivo.txt";
                    modelo.reemplazarPalabra(palabraOriginal, palabraNueva, nuevoArchivo); 
                    String textoModificado = modelo.leerArchivo(); 
                    vision.getTextAreaModificado().setText(textoModificado); 
                    JOptionPane.showMessageDialog(vision.getTextAreaOriginal(), "Reemplazo realizado. Nuevo archivo guardado como: " + nuevoArchivo);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(vision.getTextAreaOriginal(), "Error al reemplazar la palabra.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
}


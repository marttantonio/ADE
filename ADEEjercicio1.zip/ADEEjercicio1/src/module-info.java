/**
 * 
 */
/**
 * 
 */
module ADEEjercicio1 {
	requires java.desktop;
}